
def det(L):
	#Code to get the determinant of the matrix
	#Print the value of the derterminant.
