def freqcounter(L):
	#frequencycounter() takes list of lists and saves each distint string with the count into a dictionary 
	#and outputs the dictonary

