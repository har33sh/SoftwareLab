def make_list():
	pass

def binsearch(l,x):
	#Code to search the number x in l.
	#print the number of steps taken to reach
	if x in l:
		return l.index(x)
	return -1
	pass


