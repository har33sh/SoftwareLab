def make_list():
	pass

def mysort(l):
	#Code to sort the file should be written here.
	#Print the sorted list
	l.sort()
	return l

#lis=make_list()
#mysort(lis)
