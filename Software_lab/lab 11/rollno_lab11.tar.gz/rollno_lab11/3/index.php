<?php
	echo "Should contain one button for each action <br>";
	echo "Form should submit to process.php <br>";
?>
