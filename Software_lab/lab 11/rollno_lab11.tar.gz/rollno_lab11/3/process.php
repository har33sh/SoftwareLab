<?php
	echo "Should connect to mysql db and perform the required actions as per request from index.php";
?>
