<!DOCTYPE HTML>
<html>
	<head>
    	<!-- Title of Page -->
        <title>
       		Fill in the title of your page
        </title>
        
        <!-- jQuery local -->
        <script src="../base/jquery.js"></script>
        
        <!-- Bootstrap -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">        
		<script src="../bootstrap/js/bootstrap.min.js"></script>
		
		<script>
			<!-- Javascript goes here -->
		</script>
                
    </head>
    
    <body>
    
    	 <div class="container">
        	
        	<!-- Class row indicates a new page wide divison -->
            <div class="row">
            
            	<div class="col-xs-12 page-header">
                	<span style="font-size:24px">Upload Image</span>                		
                </div>
            </div>
        
        	<div class="row">
            	
            	<div class="col-xs-12 " style="min-height:500px;">
               		Form for image upload that validates the image type as jpg (only .jpg format) <br>
               		Image type check to be done using javascript <br>
               		Sends data to upload.php
                </div>
                		
         	</div>
         	
         	<div class="row">
         		<div class="col-xs-12" style="text-align:center; background-color:black; color:white; padding:10px">
                    
                    <p>
                        <span class="glyphicon glyphicon-copyright-mark"></span> Prashanth, 2016 <br>
                        All Rights Reserved.
                    </p>
                </div>
            </div>
                        
       	</div>
        <!-- End of page container -->
                            
        
        
    </body>
</html>
