<!DOCTYPE HTML>
<html>
	<head>
    	
    	<!-- Change author to your name -->
    	<meta name="author" content="Prashanth"/>
        
        <!-- Title of Page -->
        <title>
       		Homepage || Photo Album
        </title>
        
        <!-- Bootstrap -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">        
		<script src="../bootstrap/js/bootstrap.min.js"></script>
		
		<script>
			<!-- Javascript goes here -->
		</script>
		        
    </head>
    
    <body>
    
    	<!-- Page Container -->
        <div class="container">
        	
            <div class="row">
            	<div class="col-xs-12 jumbotron well well-lg">
                	<strong> Photo Album Login </strong> <br/>
                </div>
            </div>
        
        	<div class="row" style="min-height:500px;">
            	<div class="col-xs-12">
            	
            		Make your login form here <br>
            		With fields, username and password <br> 
            		The form submits to login.php
            		
               	</div> 
         	</div>
         	
         	<div class="row">
         		<div class="col-xs-12" style="text-align:center; background-color:black; color:white; padding:10px">
                    
                    <p>
                        <span class="glyphicon glyphicon-copyright-mark"></span> Prashanth, 2016 <br>
                        All Rights Reserved.
                    </p>
                </div>
            </div>
                        
       	</div>
        <!-- End of page container -->
                            
        
    </body>
</html>
