<?php
	echo "Script to save <strong>valid images</strong> to images/ directory with appropriate image ID <br>";
	echo "If error display error and a back button to navigate to previous page <br>";
	echo "If successful take it to the album page where the newly uploaded image is";
?>
