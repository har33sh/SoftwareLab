<?php
	echo "Gets data posted from index.php <br>";
	echo "If username and passwords don't match, print login error <br> ";
	echo "Also provide a back button in case of login error <br>";
	echo "Otherwise redirect to album.php <br>";
?>
