<?php
if (($_POST["uname"]=="user1") && ($_POST["pword"]=="user1pass"))
print "successful";
else
print "unsuccessful";

?>
