<?php
$n1 = $_POST["num1"];
$n2 = $_POST["num2"];
$sum = $n1 + $n2 ;
print "<h5>Sum</h5>";
print $sum;
?>

<h1> The script Calculated Sum at the server </h1>
