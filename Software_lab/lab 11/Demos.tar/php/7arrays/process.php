<?php
$a = array ("hallo", "world", "how", "are", "you");
print "<h5>array</h5>";
print  "<br>";
print $a[0] . " " . $a[1] . " " . $a[2];
?>

