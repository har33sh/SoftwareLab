<?php
$a = array ("a"=>"hallo", "b"=>"world", "c"=>"how", "d"=>"are", "e"=>"you");
print "<h3>associative array</h3>";
print  "<br>";
print $a["a"] . " " . $a["b"] . " " . $a["e"];
?>

