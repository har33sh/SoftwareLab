
<?php
include 'old.php'; // require can also be used
	// on error in reused file, include terminates, require continues



echo " world";
?>
