awk -f script7.awk $1|sort -k 2n
