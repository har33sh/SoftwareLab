#!/bin/bash

TMP_FILE='temp'
FILE='ls_sort'
stat --printf '%n\t%.16x\t%A\n' * >> $TMP_FILE
echo -e "File Name\tTime\tPermission" > $FILE
cat $TMP_FILE >> $FILE
rm $TMP_FILE
