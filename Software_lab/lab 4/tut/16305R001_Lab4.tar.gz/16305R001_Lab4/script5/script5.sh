#!/bin/bash

if [ $# -ne 1 ]
then
    echo "No arguments given"
else
    for i in $(ls)
    do
	if [ "${i##*.}" == "$1" ]
	then
	    j=${i%%.*}`date +%d-%m-%Y`.${i##*.}
	    mv $i $j
	fi
    done
fi

