#!/bin/bash

if [ $# -eq 0 ];
then
  echo "No agruments given"
else
  echo $(($1 * ($1 + 1) / 2))
fi
    
