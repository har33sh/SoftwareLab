#!/bin/bash

if [ $# -eq 0 ]
then
  echo "No arguments given"
else
    for i in `cat $1`
    do
	if [ ! -d $i ]
	then
	    mkdir $i
	    echo "created $i"
	else
	    echo "could not create $i"
	fi
    done
fi
