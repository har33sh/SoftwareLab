#!/bin/bash

if [ $# -ne 1 ]
then
    echo "Arguments missing"
else
    INPUT='ls_sort'
    TMP_FILE='temp'
    head -n 1 ls_sort > $TMP_FILE
    cat ls_sort | sed 1d | sort -k $1 -r >> $TMP_FILE
    cat $TMP_FILE > $INPUT
    rm $TMP_FILE
fi
