#!/bin/bash

sum=0

if [ $# -ne 1 ]
then
    echo "Arguments missing"
else
    for i in `find $1 -type f`
    do
	currentCount=`cat $i | grep for | wc -l`
	sum=`expr $sum + $currentCount`
    done
    echo $sum
fi
