#!/bin/bash

if [ $# -eq 0 ]
then
    echo "No agruments given"
else
    find $1 -maxdepth 1 -type d | echo $((`wc -l` - 1))
fi
