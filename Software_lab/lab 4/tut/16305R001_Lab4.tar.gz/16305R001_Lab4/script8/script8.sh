#!/bin/bash

if [ $# -ne 4 ]
then
    echo "Arguments missing"
else
    TMP_FILE='temp'
    cat $1 $2 > $TMP_FILE
    sort -k $4 $TMP_FILE > $3
    rm $TMP_FILE
fi

    
