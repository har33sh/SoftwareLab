#!/bin/bash

if [ $# -ne 1 ]
then
    echo "Arguments missing"
else
    sum=0
    for i in `find $1 -maxdepth 1 -type f`
    do
	currentCount=`cat $i | wc -l`
	sum=`expr $sum + $currentCount`
    done
    echo $sum
fi
