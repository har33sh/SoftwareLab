#!/bin/bash

if [ $# -ne 2 ]
then
    echo "Insufficient arguments given"
else
    for i in $(ls)
    do
	if [ "${i##*.}" == "$1" ]
	then
	    j=${i%%.*}.$2
	    mv $i $j
	fi
    done
fi
