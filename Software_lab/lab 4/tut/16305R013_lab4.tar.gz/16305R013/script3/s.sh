line="hello"
echo -f $line
	if [ -f "$line" ];
	then
		echo "could not create "$line
	else
		mkdir $line
		echo "created " $line
	fi    
	
