while read line; do    
	if [ -f "$line" ];
	then
		echo "could not create "$line
	else
		mkdir $line
		echo "created " $line
	fi    
	done < $1
