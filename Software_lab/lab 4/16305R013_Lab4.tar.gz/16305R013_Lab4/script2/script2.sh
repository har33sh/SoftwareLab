cd $1
ls -l |grep -c ^d

