sed s/hallo/hi/  $1 > $2
