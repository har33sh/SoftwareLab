sed s/[\ ]*/'\t'/g $1 
