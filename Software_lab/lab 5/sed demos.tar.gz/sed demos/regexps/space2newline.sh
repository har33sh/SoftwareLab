sed s/[\ ]*/'\n'/g $1 
