sed s/[AHah]*B/P/g $1 
