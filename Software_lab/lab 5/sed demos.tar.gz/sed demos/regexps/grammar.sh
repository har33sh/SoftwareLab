sed 's/I[\ ]\+has/I have/g' $1
