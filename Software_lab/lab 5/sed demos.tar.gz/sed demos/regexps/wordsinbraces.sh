sed 's/[a-z]\+/(&)/g' $1
