sed s/[A]*B/P/g $1 
