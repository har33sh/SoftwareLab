sed -i s/hallo/hi/ $1
