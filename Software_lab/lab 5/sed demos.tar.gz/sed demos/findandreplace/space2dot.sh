sed  's/ /./g' $1
