sed s/hi/hallo/ $1 
