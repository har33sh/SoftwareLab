sed   -f hallo2hi.sed  in
