sed 's/hallo/hi/g' $1 
