sed -ibk 's/ /./' $1
