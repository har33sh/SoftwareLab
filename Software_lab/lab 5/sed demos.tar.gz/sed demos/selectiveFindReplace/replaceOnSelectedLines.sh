sed 2,5s/hallo/hi/ $1 
