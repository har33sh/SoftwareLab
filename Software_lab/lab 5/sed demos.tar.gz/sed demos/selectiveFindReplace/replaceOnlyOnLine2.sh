sed 2s/hallo/hi/ $1 
