sed 2!s/hallo/hi/ $1 
