sed 's/you/we/3' $1>output3
