Place your compressed .tar.gz of your submission file here. Make sure the compressed file format is as mentioned in the labstatement. For new queries regarding input/output formats check the updated lab statement.

To run evaluator:
	bash eval.sh
