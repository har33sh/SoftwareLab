awk  -f  6.awk  inputdata6  |sort  -k1  |gnuplot  6.plot
