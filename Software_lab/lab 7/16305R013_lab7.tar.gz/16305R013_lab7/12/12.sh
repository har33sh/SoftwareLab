awk -f 12.awk inputdata12 > 12.dot
dot -Tpdf 12.dot > 12.pdf
