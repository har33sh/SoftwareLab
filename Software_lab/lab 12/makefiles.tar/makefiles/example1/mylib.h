#include <string>
using namespace std;
int count (string s);
