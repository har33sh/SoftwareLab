#include <iostream>

#include "mylib.h"

string s;


int count (string s) {


 return s.length()+100;


}
